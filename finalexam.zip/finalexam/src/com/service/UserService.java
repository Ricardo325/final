package com.service;

import com.entity.User;

public interface UserService {
    boolean findUser(User user);

    boolean deleUser(int id);

}
