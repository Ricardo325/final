package com.entity;
import java.util.List;
public class Page{
    private int pageNum=1;
    private int pageSize;
    private int totalRecord;
    private int totalPage;
    private int start;//在页面显示的第一页
    private int end;//在页面显示的最后一页
    public Page(int pageNum,int pageSize,int totalRecord){
        this.pageNum=pageNum;
        this.pageSize=pageSize;
        this.totalRecord=totalRecord;
        if(totalRecord%pageSize==0){
            this.totalPage=totalRecord/pageSize;
        }else {
            this.totalPage = totalRecord / pageSize + 1;
        }
        if(totalPage<=3){
            this.start=1;
            this.end=totalPage;
        }else{
            this.start=pageNum-1;
            this.end=pageNum+1;
            if(this.start<=0){
                this.start=1;
                this.end=3;
            }
            if(this.end>totalPage){
                this.end=totalPage;
                this.start=this.end-2;
            }
        }
    }
    public int getPageNum() { return pageNum; }
    public void setPageNum(int pageNum) { this.pageNum = pageNum; }
    public int getPageSize() { return pageSize;}
    public void setPageSize(int pageSize) { this.pageSize = pageSize; }
    public int getTotalRecord() { return totalRecord; }
    public void setTotalRecord(int totalRecord) { this.totalRecord = totalRecord; }
    public int getTotalPage() { return totalPage; }
    public void setTotalPage(int totalPage) { this.totalPage = totalPage; }
    public int getStart() { return start; }
    public void setStart(int start) { this.start = start; }
    public int getEnd() { return end; }
    public void setEnd(int end) { this.end = end; }}
