package com.Test;

import com.dao.UserDao;
import com.dao.impl.UserDaoImpl;
import com.entity.User;

public class UserTest {
    public static void main(String[] args) {
        UserDao us=new UserDaoImpl();
        User u=new User();
        us.findUser(u);
        u.setName("lhx");
        u.setPassword("zz");
        us.insertUser(u);
    }
}
