package com.servlet;

import com.dao.NewsDao;
import com.dao.impl.NewsDaoImpl;
import com.entity.News;
import com.entity.Page;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class NewsQuery extends HttpServlet{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");

        List<News> list = new ArrayList<News>();
        int pageNum=Integer.parseInt(request.getParameter("pageNum"));
        int pageSize=3;
        NewsDao newsDao =new NewsDaoImpl();
        list = newsDao.selectAll(pageNum,pageSize);
        int count=newsDao.getcount();
        Page page=new Page(pageNum,pageSize,count);
        request.setAttribute("list",list);
        request.setAttribute("page",page);
        request.getRequestDispatcher("home.jsp?pageNum=1").forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException {
            doGet(request,response);
    }
}
