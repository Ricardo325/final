



 var aa= window.onload=  function tick() {
var hours, minutes, seconds;
var intHours, intMinutes, intSeconds;
var today;
today = new Date();
intYear = today.getFullYear();
intMonth = today.getMonth() + 1;
intDay = today.getDate();
intHours = today.getHours();
intMinutes = today.getMinutes();
intSeconds = today.getSeconds();

if (intHours == 0) {
hours = "00:";
}
else if (intHours < 10) { 
hours = "0" + intHours+":";
} else {
hours = intHours + ":";
}

if (intMinutes < 10) {
minutes = "0"+intMinutes+":";
} else {
minutes = intMinutes+":";
}
if (intSeconds < 10) {
seconds = "0"+intSeconds+" ";
} else {
seconds = intSeconds+" ";
} 
timeString = intYear + "年" + intMonth + "月" + intDay + "日" + " " + hours+minutes+seconds;
Clock.innerHTML = timeString;
window.setTimeout("tick();", 1000);
}



//轮播
var bb=window.onload = function()
{
	var container = document.getElementById("container");
	var list = document.getElementById("list");
	var dots = document.getElementById("dot").getElementsByTagName("span");//getElementByTagName 可以返回带有指定标签名的对象的集合。
	var prev = document.getElementById("prev");
	var next = document.getElementById("next");
	var index = 1;//亮起第几个小圆点
	var animated = false;//是否在动画 初始值默认为不在动画
	var timer;
	
	function showDots()
	{
		for(var i = 0; i < dots.length; i ++)
		{
			if(dots[i].className=="on")
			{
				dots[i].className = "";
			}
		}//把之前显示的复原
		dots[index-1].className = "on";//新的显示的圆点
	}
	function animate(offset)
	{
		animated = true;
		var newLeft = parseInt(list.style.left) + offset;//目标值,parseInt(list.style.left)是每次移动的新的位置
		var time = 600;//位移总时间
		var interval = 10;//位移时间间隔
		var speed = offset/(time/interval);//time/interval是位移次数 speed是每次位移量
		
		function go()
		{
			//speed<0是向左移动 本身的list.style.left>目标值
			if((speed<0 && parseInt(list.style.left)>newLeft) ||
				(speed>0 && parseInt(list.style.left)<newLeft))
			{
				list.style.left = parseInt(list.style.left)+speed+'px';//还未到达目标值，可以继续移动
				setTimeout(go,interval);
			}
			else 
			{
				animated = false;
				list.style.left = newLeft + 'px';//已经达到目标值，停止移动
				if(newLeft>-260)
				{
					list.style.left =-1040 + 'px';
				}
				if(newLeft<-1040)
				{
					list.style.left =-260 + 'px';
				}
			}
		}
		go();
	}
	
	function play()
	{
		//setTimeout只能执行一次，所以不用它
		timer = setInterval(function()
		{
			next.onclick();
		},3000);//setInterval可以一直执行
	}
	
	function stop()
	{
		clearInterval(timer);//清除timer这个定时器
	}
	next.onclick = function()
	{
		if(index == 4)
			index = 1;
		else index += 1;
		showDots();
		if(!animated)
		{
			animate(-260);	
		}
	}
	
	prev.onclick = function()
	{
		if(index == 1)
			index = 4;
		else index -= 1;
		showDots();
		if(!animated)
		{
			animate(260);
		}
	}
	
	for(var i = 0; i < dots.length; i ++)
	{
		dots[i].onclick = function()
		{
			if(this.className == "on")
			{
				return ;
			}
			//var myIndex = myIndex;这样是不可以的因为index属性是自定义属性！和id style那些是不一样的
			var myIndex = parseInt(this.getAttribute("index"));//用来存放自身的index值(目标的)
			//getAttribute可以获取自定义属性和DOM自带属性
			var offset = -260*(myIndex-index);//index是目前的 第几张图片
			index = myIndex;
			if(!animated)
			{
				animate(offset);
			}
			showDots();
		}
	}
	container.onmouseover = stop;
	container.onmouseout = play;
	
	play();//初始默认是播放状态
	}

window.onload=function()
{
	aa();bb();
}




 var myclick = function(v) {  
                var llis = document.getElementsByTagName("li");  
                for(var i = 0; i < llis.length; i++) {  
                    var lli = llis[i];  
                    if(lli == document.getElementById("tab" + v)) {  
                        lli.style.color = "#800000"; 
                    } else {  
                        lli.style.color = "black";   
                    }  
                }  
  
                var divs = document.getElementsByClassName("tab_css");  
                for(var i = 0; i < divs.length; i++) {  
  
                    var divv = divs[i];  
  
                    if(divv == document.getElementById("tab" + v + "_content")) {  
                        divv.style.display = "block";  
                    } else {  
                        divv.style.display = "none";  
                    }  
                }  
  
            }  