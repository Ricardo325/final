package com.servlet;

import com.dao.NewsDao;
import com.dao.UserDao;
import com.dao.impl.UserDaoImpl;
import com.entity.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class UserInsert extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if(request.getParameter("password1").equals(request.getParameter("password2"))) {
            User u = new User();
            u.setName(request.getParameter("name"));
            u.setPassword(request.getParameter("password1"));
            UserDao ud = new UserDaoImpl();
            ud.insertUser(u);
            request.getRequestDispatcher("login.jsp").forward(request,response);
        } else {
            request.getRequestDispatcher("reg.jsp").forward(request,response);
        }
    }
}
