var name=document.getElementById("name");
var nullname=document.getElementById("nullname");
var password=document.getElementById("password");
var nullpassword=document.getElementById("nullpassword");
function tname()
{
    var name=document.getElementById("name");
    var nullname=document.getElementById("nullname");
    if(name==null||name=="")
    {
        nullname.innerHTML="用户名不能为空！";
        return false;
    }
    else  if(name.length<2||name.length>=20)
    {
        nullname.innerHTML="用户名长度为2--20个字符长度！";
        return false;
    }
    else
    {
        nullname.innerHTML="";
        return true;
    }   

}
    
function ppwd()
{
    var password=document.getElementById("password").value;
    var nullpassword=document.getElementById("nullpassword");
    if(password==null||password=="")
    {
        nullpassword.innerHTML="密码不能为空！";
        return false;
    }
    else
    {
        nullpassword.innerHTML="";
        return true;
    }    
}
function last()
{
    	
    if(name.length==null||password.length==null)
    {
    alert("请输入完整信息");
    }
    else
    {
    	return true;
    }
}

