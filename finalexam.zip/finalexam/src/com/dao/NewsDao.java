package com.dao;


import com.entity.News;

import java.util.List;

public interface NewsDao {
    boolean insertNews(News news);

    boolean deNews(int id);

    boolean SelectByTitle(String name);

    boolean SelectNews(News news);
    public  List<News> selectAll(int pageNum, int pageSize);
    public int getcount();
}
