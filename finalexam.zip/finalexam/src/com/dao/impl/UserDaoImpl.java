package com.dao.impl;

import com.dao.UserDao;
import com.entity.User;
import com.util.jdbcUtil;

import java.awt.geom.FlatteningPathIterator;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements UserDao {
/*
        public boolean findUser(User user){
        boolean flag = false;
        ResultSet rs = null;
        Connection conn = jdbcUtil.getConnection();
        String sql = "select * from t_user where name = ? and password = ?";
        try {
            PreparedStatement ptmt = conn.prepareStatement(sql);
            ptmt.setString(1,"name");
            ptmt.setString(2,"password");
            rs = ptmt.executeQuery();
            while(rs.next()){
                flag = true;
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return flag;
    }*/
public  boolean findUser(User user) {
    boolean flag = false;
    try {
        Connection conn = jdbcUtil.getConnection();
        String sql = "SELECT * FROM t_user WHERE name=? AND password=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1,user.getName());
        ps.setString(2,user.getPassword());
        ResultSet rs = ps.executeQuery();//executeQuery()方法会把数据库响应的查询结果存放在rs类对象中供我们使用
        while (rs.next()) {
            flag = true;

        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return flag;
}

  /*  public boolean findUser(User user2) {
        boolean flag = true;
        if (user2.getName().equals("admin") && user2.getPassword().equals("admin")) {

        } else {
            flag = false;
        }
        return flag;
    }*/

    public boolean insertUser(User user) {
        boolean flag = true;
        ResultSet rs = null;
        Connection conn = jdbcUtil.getConnection();
        String sql = "INSERT INTO t_user(name,password) VALUES(?,?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, user.getName());
            ps.setString(2, user.getPassword());
            if (ps.executeUpdate() > 0) {
                flag = true;
            }
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
        return flag;
    }

    @Override
    public boolean deUser(int id) {
        boolean flag = true;
        ResultSet rs = null;
        Connection conn = jdbcUtil.getConnection();
        String sql = "DELETE  FROM t_user WHERE id=" + id;
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            if (ps.executeUpdate() > 0) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    public boolean SelectByName(String name) {
        boolean flag = false;
        Connection conn = jdbcUtil.getConnection();
        String sql = "SELECT * FROM t_user WHERE name = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    public boolean SelectUser(User user) {
        boolean flag = false;
        try {
            Connection conn = jdbcUtil.getConnection();
            String sql = "SELECT * FROM t_user WHERE name=? and password=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, user.getName());
            ps.setString(2, user.getPassword());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }
}

