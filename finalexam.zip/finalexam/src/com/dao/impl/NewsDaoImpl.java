package com.dao.impl;

import com.dao.NewsDao;
import com.entity.News;
import com.util.jdbcUtil;
import java.util.Date;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static com.util.jdbcUtil.getConnection;

public class NewsDaoImpl implements NewsDao {
    public boolean insertNews(News news) {
        boolean flag = false;
        ResultSet rs = null;
        Connection conn = getConnection();
        String sql = "INSERT INTO t_news(id,title,time,content,author,type) VALUES(?,?,?,?,?,?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, news.getId());
            ps.setString(2, news.getTitle());
            ps.setDate(3, news.getTime());
            ps.setString(4, news.getContent());
            ps.setString(5, news.getAuthor());
            ps.setString(6, news.getType());
            if (ps.executeUpdate() > 0) {
                flag = true;
            }
        } catch (SQLException e1) {
            e1.printStackTrace();
        }
        return flag;
    }

    public boolean deNews(int id) {
        boolean flag = true;
        ResultSet rs = null;
        Connection conn = getConnection();
        String sql = "DELETE  FROM t_news WHERE id=" + id;
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            if (ps.executeUpdate() > 0) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    public boolean SelectByTitle(String title) {
        boolean flag = false;
        Connection conn = getConnection();
        String sql = "SELECT * FROM t_news WHERE title = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, title);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    public boolean SelectNews(News news) {
        boolean flag = false;
        try {
            Connection conn = getConnection();
            String sql = "SELECT * FROM t_news WHERE id=? and title=? and time=? and content=? and author=? and type=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, news.getId());
            ps.setString(2, news.getTitle());
            ps.setDate(3, news.getTime());
            ps.setString(4, news.getContent());
            ps.setString(5, news.getAuthor());
            ps.setString(6, news.getType());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return flag;
    }

    public List<News> selectAll(int pageNum, int pageSize) {
        List<News> list = new ArrayList<News>();
        ResultSet rs = null;
        try {
            Connection conn = getConnection();
            String sql = "SELECT * FROM t_news limit ?,?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, pageNum * pageSize - pageSize);
            ps.setInt(2, pageSize);
            rs = ps.executeQuery();
            while (rs.next()) {
                News  news = new News();
                news.setId(rs.getInt("id"));
                news.setTitle(rs.getString("title"));
                news.setTime(rs.getString("time"));
                news.setContent(rs.getString("content"));
                news.setAuthor(rs.getString("author"));
                list.add(news);
             //   System.out.println(news.getTitle());
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    public int getcount() {
        String sql = "select count(*) from t_news";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        conn = getConnection();
        int count = 0;
        try {
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            rs.first();
            count = rs.getInt(1);
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                conn.close();
                ps.close();
            } catch (Exception ex) {
                ex.printStackTrace();
                ;
            }
        }
        return count;
    }
    public int update(News news){
        int id=news.getId();
        boolean flag = false;
        int i=0;
        ResultSet rs = null;
        try {
            Connection conn = getConnection();
            String sql = "UPDATE t_news SET title=?,content=?,author=? WHERE id="+ id;
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1,news.getTitle());
            ps.setString(2,news.getContent());
            ps.setString(3,news.getAuthor());
            i = ps.executeUpdate();
            /*while (rs.next()){
                News  news = new News();
                news.setAuthor(rs.getString("author"));
                news.setTitle(rs.getString("title"));
                news.setTime(rs.getString("time"));
                news.setContent(rs.getString("content"));
            }*/
        }catch (SQLException e){
            e.printStackTrace();
        }
        return i;
    }

}


