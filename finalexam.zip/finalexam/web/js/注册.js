var name=document.getElementById("name");
    var nullname=document.getElementById("nullname");
    var password=document.getElementById("password");
    var nullpassword=document.getElementById("nullpassword");
    var tpassword=document.getElementById("tpassword");
    var nulltpassword=document.getElementById("nulltpassword");
    var eamil=document.getElementById("email");
    var nullemail=document.getElementById("nullemail");
    var tel=document.getElementById("tel");
    var nulltel=document.getElementById("nulltel")
   
    function tname()
    {
       var name=document.getElementById("name").value;
       var nullname=document.getElementById("nullname");
       if(name==null||name=="")
        {
           nullname.innerHTML="用户名不能为空！";
           return false;
        }
        else  if(name.length<2||name.length>=20)
        {
           nullname.innerHTML="用户名长度为2--20个字符长度！";
           return false;
        }
        else
        {
           nullname.innerHTML="";
           return true;
        }   

    }
    
    function ppwd()
    {
        var password=document.getElementById("password").value;
        var nullpassword=document.getElementById("nullpassword");
        if(password==null||password=="")
        {
           nullpassword.innerHTML="密码不能为空！";
           return false;
        }
        else
        {
           nullpassword.innerHTML="";
           return true;
        }    
    }
    
    function tpwd()
    {
        var password=document.getElementById("password").value;
        var tpassword=document.getElementById("tpassword").value;
        var nulltpassword=document.getElementById("nulltpassword");
        alert(password);
        alert(tpassword);
        if(tpassword==null||tpassword=="")
        {
           nulltpassword.innerHTML="确认密码不能为空！！！";
           return false;
        }
        else if(tpassword!=password)
        {
           nulltpassword.innerHTML="两次密码输入不一致";
           return false;
        }
        else
        {
           nulltpassword.innerHTML="";
           return true;
        }      
    } 
   
    function eemail()
    {
        var eamil=document.getElementById("email").value;
        var nullemail=document.getElementById("nullemail");
        var reg=/^[a-zA-Z0-9_-]+@(126.com|163.com|qq.com|sohu.com|sina.com|hotmail.com|gmail.com|yahoo.cn)$/;

        if(eamil==null||eamil=="")
        {
           nullemail.innerHTML="Email地址不能为空";
           return false;

        }
        else if(!reg.test(eamil))
        {
            nullemail.innerHTML="请输入正确的Email地址！！";
            return false;   
        }
        else
        {
           nullemail.innerHTML="";
           return true;
        }
    }
    
    function ttel()
    {
        var tel=document.getElementById("tel").value;
        var nulltel=document.getElementById("nulltel")
        var reg=/^[1]{1}[3,5,8]{2}[0-9]{8}$/
        if(tel==null||tel=="")
        {
           nulltel.innerHTML="手机号不能为空！！！";
           return false;
        }
        else if(tel.length!=11||!reg.test(tel))
        {
           nulltel.innerHTML="请正确填写手机号";
           return false;
        }

        else 
        {
           nulltel.innerHTML="";
           return true;
        }
    }

   function last()
    {
    	
    	if(name.length==null||password.length==null||tpassword.length==null||email.length==null||tel.length==null)
    	alert("请输入完整信息");
    }
