package com.service;

import com.entity.News;

public interface NewsService {
    boolean insertNews(News news);

    boolean deNews(int id);

    boolean SelectByTitle(String name);

    boolean SelectNews(News news);
}
