package com.dao;

import com.entity.News;
import com.entity.User;

import java.util.List;

public interface UserDao {
    boolean findUser(User user);

    boolean insertUser(User user);

    boolean deUser(int id);

    boolean SelectByName(String name);

    boolean SelectUser(User user);


}
