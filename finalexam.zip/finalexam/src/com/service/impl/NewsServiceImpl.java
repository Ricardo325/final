package com.service.impl;

import com.entity.News;
import com.service.NewsService;

public class NewsServiceImpl implements NewsService {
    @Override
    public boolean insertNews(News news) {
        return false;
    }

    @Override
    public boolean deNews(int id) {
        return false;
    }

    @Override
    public boolean SelectByTitle(String name) {
        return false;
    }

    @Override
    public boolean SelectNews(News news) {
        return false;
    }
}
