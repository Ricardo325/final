package com.servlet;

import com.dao.NewsDao;
import com.entity.News;

import javax.servlet.http.HttpServlet;
import java.util.ArrayList;
import java.util.List;

public class NewsSelect extends HttpServlet{
    List<News> list = new ArrayList<News>();

    public void setList(List<News> list) {
        System.out.println();
    }

    int num = 0;
}
