package com.Test;

import com.dao.NewsDao;
import com.dao.impl.NewsDaoImpl;
import com.entity.News;

public class NewsTest {
    public static void main(String[] args) {
        NewsDao newsDao=new NewsDaoImpl();
        News news = new News();
//        news.setTitle("hahaha");
//        news.setContent("content");
//        news.setAuthor("Ricardo");
//        news.setType("还有type啊");
//        newsDao.insertNews(news);
//        newsDao.deNews(16);
//        newsDao.SelectByTitle("123");
//        newsDao.SelectNews(news);
//         newsDao.selectAll();
    }
}
