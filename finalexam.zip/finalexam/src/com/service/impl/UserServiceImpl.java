package com.service.impl;

import com.dao.UserDao;
import com.dao.impl.UserDaoImpl;
import com.entity.User;
import com.service.UserService;



public class UserServiceImpl implements UserService {


    @Override
    public boolean findUser(User user) {
//        UserDao userDao = new UserDaoImpl();
//        User u = new User();
//        u.setName(user.getName());
//        u.setPassword(user.getPassword());

        return false;
    }

    public boolean deleUser(int id) {
//        User user = new User();
//        UserDao userDao = new UserDaoImpl();
//        boolean flag = false;

        return false;
    }
}
