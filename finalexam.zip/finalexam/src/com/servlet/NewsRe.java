package com.servlet;

import com.dao.NewsDao;
import com.dao.impl.NewsDaoImpl;
import com.entity.News;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class NewsRe extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        NewsDao newsDao = new NewsDaoImpl();
        News news = new News();
        int id = Integer.parseInt(request.getParameter("id"));
        news.setId(id);
        news.setTitle(request.getParameter("title"));
        news.setTime(request.getParameter("time"));
        news.setAuthor(request.getParameter("author"));
        news.setContent(request.getParameter("content"));
        //自动获取当前时间，不用前台输入
        news.setContent(request.getParameter("content"));
        int flag = ((NewsDaoImpl) newsDao).update(news);
        if (flag==1) {
            request.getRequestDispatcher("upload.jsp").forward(request, response);
        } else {
            request.getRequestDispatcher("delete.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
